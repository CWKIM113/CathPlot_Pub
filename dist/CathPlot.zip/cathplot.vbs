' �� cmd â���� �����ϱ�
Set objShell = CreateObject("WScript.Shell")
objShell.CurrentDirectory = Left(WScript.ScriptFullName, InStrRev(WScript.ScriptFullName, "\"))
rem objShell.Run """D:\CathPlot\dist\CathPlot\CathPlot.exe"""
objShell.Run """D:\CathPlot\CathPlot.exe"""